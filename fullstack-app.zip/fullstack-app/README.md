# 📝 Gestor de Tareas Full Stack

Aplicación completa de gestión de tareas desarrollada con Angular, Node.js y MySQL, orquestada con Docker Compose.

## 🏗️ Arquitectura

```
┌─────────────────┐
│   Frontend      │
│   (Angular)     │
│   Puerto: 4200  │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│   Backend       │
│   (Node.js)     │
│   Puerto: 3000  │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│   Database      │
│   (MySQL)       │
│   Puerto: 3306  │
└─────────────────┘
```

## 🚀 Inicio Rápido

### Prerrequisitos
- Docker
- Docker Compose

### Instalación y ejecución

1. Clonar o descargar el proyecto

2. Desde el directorio raíz, ejecutar:
```bash
docker-compose up -d
```

3. Acceder a la aplicación:
   - Frontend: http://localhost:4200
   - Backend API: http://localhost:3000
   - MySQL: localhost:3306

### Comandos útiles

```bash
# Iniciar servicios
docker-compose up -d

# Ver logs
docker-compose logs -f

# Detener servicios
docker-compose down

# Detener y eliminar volúmenes (elimina datos)
docker-compose down -v

# Reconstruir imágenes
docker-compose up -d --build
```

## 📦 Componentes

### Frontend (Angular)
- Framework: Angular 17
- Puerto: 4200
- Características:
  - Interfaz moderna y responsiva
  - Operaciones CRUD completas
  - Consumo de API REST
  - Gestión de estado reactiva

### Backend (Node.js + Express)
- Runtime: Node.js 18
- Framework: Express
- Puerto: 3000
- Endpoints REST:
  - GET /api/tasks - Listar tareas
  - GET /api/tasks/:id - Obtener tarea
  - POST /api/tasks - Crear tarea
  - PUT /api/tasks/:id - Actualizar tarea
  - DELETE /api/tasks/:id - Eliminar tarea

### Base de Datos (MySQL)
- Versión: MySQL 8.0
- Puerto: 3306
- Base de datos: taskdb
- Usuario: taskuser
- Persistencia de datos con volúmenes Docker

## 🔧 Configuración

### Variables de Entorno

El archivo `docker-compose.yml` incluye las siguientes variables:

```yaml
MYSQL_ROOT_PASSWORD: rootpass
MYSQL_DATABASE: taskdb
MYSQL_USER: taskuser
MYSQL_PASSWORD: taskpass
```

## 📊 Persistencia de Datos

Los datos se persisten mediante volúmenes Docker:
- `mysql_data`: Almacena los datos de MySQL

Para eliminar todos los datos:
```bash
docker-compose down -v
```

## 🌐 Red

Todos los servicios están conectados a través de la red `fullstack-network`, permitiendo la comunicación entre contenedores mediante sus nombres de servicio.

## 🛠️ Desarrollo

Para desarrollo local sin Docker:

### Backend
```bash
cd backend
npm install
npm start
```

### Frontend
```bash
cd frontend
npm install
npm start
```

## 📝 Estructura del Proyecto

```
fullstack-app/
├── frontend/
│   ├── src/
│   ├── Dockerfile
│   └── package.json
├── backend/
│   ├── server.js
│   ├── Dockerfile
│   └── package.json
├── database/
│   └── init.sql
└── docker-compose.yml
```

## 🎯 Funcionalidades

✅ Crear tareas
✅ Listar tareas
✅ Editar tareas
✅ Eliminar tareas
✅ Marcar tareas como completadas
✅ Persistencia de datos
✅ Interfaz responsiva
✅ API REST completa

## 📚 Tecnologías Utilizadas

- **Frontend**: Angular 17, TypeScript, RxJS
- **Backend**: Node.js, Express, MySQL2
- **Base de Datos**: MySQL 8.0
- **Orquestación**: Docker, Docker Compose
- **Otros**: CORS, Body Parser

## 👤 Autor

Proyecto desarrollado para la práctica de Computación en la Nube (COP055)
Universidad UNIR - UD4 Práctica 2

## 📄 Licencia

Proyecto educativo - Todos los derechos reservados
