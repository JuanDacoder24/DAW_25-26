import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TaskService, Task } from './task.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="container">
      <header>
        <h1>📝 Gestor de Tareas Full Stack</h1>
        <p class="subtitle">Angular + Node.js + MySQL con Docker Compose</p>
      </header>

      <div class="task-form">
        <h2>{{ editingTask ? '✏️ Editar Tarea' : '➕ Nueva Tarea' }}</h2>
        <form (ngSubmit)="saveTask()">
          <div class="form-group">
            <label for="title">Título:</label>
            <input
              type="text"
              id="title"
              [(ngModel)]="currentTask.title"
              name="title"
              placeholder="Título de la tarea"
              required
            />
          </div>
          <div class="form-group">
            <label for="description">Descripción:</label>
            <textarea
              id="description"
              [(ngModel)]="currentTask.description"
              name="description"
              placeholder="Descripción de la tarea"
              rows="3"
            ></textarea>
          </div>
          <div class="form-actions">
            <button type="submit" class="btn btn-primary">
              {{ editingTask ? 'Actualizar' : 'Crear' }}
            </button>
            <button type="button" class="btn btn-secondary" (click)="cancelEdit()" *ngIf="editingTask">
              Cancelar
            </button>
          </div>
        </form>
      </div>

      <div class="tasks-section">
        <h2>📋 Mis Tareas ({{ tasks.length }})</h2>
        
        <div *ngIf="tasks.length === 0" class="empty-state">
          <p>No hay tareas. ¡Crea tu primera tarea!</p>
        </div>

        <div class="tasks-list">
          <div *ngFor="let task of tasks" class="task-card" [class.completed]="task.completed">
            <div class="task-header">
              <div class="task-checkbox">
                <input
                  type="checkbox"
                  [checked]="task.completed"
                  (change)="toggleComplete(task)"
                  [id]="'task-' + task.id"
                />
                <label [for]="'task-' + task.id"></label>
              </div>
              <h3 [class.line-through]="task.completed">{{ task.title }}</h3>
            </div>
            <p class="task-description">{{ task.description }}</p>
            <div class="task-footer">
              <span class="task-date">{{ task.created_at | date:'short' }}</span>
              <div class="task-actions">
                <button class="btn-icon" (click)="editTask(task)" title="Editar">
                  ✏️
                </button>
                <button class="btn-icon" (click)="deleteTask(task.id!)" title="Eliminar">
                  🗑️
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      <footer>
        <p>Desarrollado con ❤️ usando Angular, Node.js y MySQL</p>
      </footer>
    </div>
  `,
  styles: [`
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    .container {
      max-width: 900px;
      margin: 0 auto;
      padding: 20px;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    header {
      text-align: center;
      margin-bottom: 40px;
      padding: 30px 0;
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
      border-radius: 15px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    }

    header h1 {
      font-size: 2.5em;
      margin-bottom: 10px;
    }

    .subtitle {
      font-size: 1.1em;
      opacity: 0.9;
    }

    .task-form {
      background: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 5px 15px rgba(0,0,0,0.08);
      margin-bottom: 30px;
    }

    .task-form h2 {
      margin-bottom: 20px;
      color: #333;
    }

    .form-group {
      margin-bottom: 20px;
    }

    .form-group label {
      display: block;
      margin-bottom: 8px;
      font-weight: 600;
      color: #555;
    }

    .form-group input,
    .form-group textarea {
      width: 100%;
      padding: 12px;
      border: 2px solid #e0e0e0;
      border-radius: 8px;
      font-size: 1em;
      transition: border-color 0.3s;
    }

    .form-group input:focus,
    .form-group textarea:focus {
      outline: none;
      border-color: #667eea;
    }

    .form-actions {
      display: flex;
      gap: 10px;
    }

    .btn {
      padding: 12px 24px;
      border: none;
      border-radius: 8px;
      font-size: 1em;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.3s;
    }

    .btn-primary {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color: white;
    }

    .btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
    }

    .btn-secondary {
      background: #f0f0f0;
      color: #333;
    }

    .btn-secondary:hover {
      background: #e0e0e0;
    }

    .tasks-section {
      margin-bottom: 40px;
    }

    .tasks-section h2 {
      margin-bottom: 20px;
      color: #333;
    }

    .empty-state {
      text-align: center;
      padding: 60px 20px;
      background: #f9f9f9;
      border-radius: 12px;
      color: #999;
      font-size: 1.1em;
    }

    .tasks-list {
      display: grid;
      gap: 20px;
    }

    .task-card {
      background: white;
      padding: 20px;
      border-radius: 12px;
      box-shadow: 0 3px 10px rgba(0,0,0,0.08);
      transition: transform 0.3s, box-shadow 0.3s;
      border-left: 4px solid #667eea;
    }

    .task-card:hover {
      transform: translateY(-3px);
      box-shadow: 0 5px 20px rgba(0,0,0,0.12);
    }

    .task-card.completed {
      opacity: 0.7;
      border-left-color: #4caf50;
    }

    .task-header {
      display: flex;
      align-items: center;
      gap: 15px;
      margin-bottom: 10px;
    }

    .task-checkbox {
      position: relative;
    }

    .task-checkbox input[type="checkbox"] {
      position: absolute;
      opacity: 0;
    }

    .task-checkbox label {
      display: block;
      width: 24px;
      height: 24px;
      border: 2px solid #667eea;
      border-radius: 6px;
      cursor: pointer;
      transition: all 0.3s;
    }

    .task-checkbox input[type="checkbox"]:checked + label {
      background: #667eea;
    }

    .task-checkbox input[type="checkbox"]:checked + label:after {
      content: '✓';
      position: absolute;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      color: white;
      font-weight: bold;
    }

    .task-header h3 {
      flex: 1;
      color: #333;
      font-size: 1.2em;
    }

    .line-through {
      text-decoration: line-through;
      color: #999 !important;
    }

    .task-description {
      color: #666;
      margin-bottom: 15px;
      line-height: 1.5;
    }

    .task-footer {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .task-date {
      font-size: 0.9em;
      color: #999;
    }

    .task-actions {
      display: flex;
      gap: 10px;
    }

    .btn-icon {
      background: none;
      border: none;
      font-size: 1.2em;
      cursor: pointer;
      padding: 5px 10px;
      border-radius: 6px;
      transition: background 0.3s;
    }

    .btn-icon:hover {
      background: #f0f0f0;
    }

    footer {
      text-align: center;
      padding: 20px;
      color: #999;
      font-size: 0.9em;
    }
  `]
})
export class AppComponent implements OnInit {
  tasks: Task[] = [];
  currentTask: Task = { title: '', description: '', completed: false };
  editingTask: boolean = false;

  constructor(private taskService: TaskService) {}

  ngOnInit(): void {
    this.loadTasks();
  }

  loadTasks(): void {
    this.taskService.getTasks().subscribe({
      next: (data) => {
        this.tasks = data;
      },
      error: (error) => {
        console.error('Error al cargar tareas:', error);
        alert('Error al conectar con el backend. Verifica que esté ejecutándose.');
      }
    });
  }

  saveTask(): void {
    if (!this.currentTask.title.trim()) {
      alert('El título es obligatorio');
      return;
    }

    if (this.editingTask && this.currentTask.id) {
      this.taskService.updateTask(this.currentTask.id, this.currentTask).subscribe({
        next: () => {
          this.loadTasks();
          this.resetForm();
        },
        error: (error) => console.error('Error al actualizar:', error)
      });
    } else {
      this.taskService.createTask(this.currentTask).subscribe({
        next: () => {
          this.loadTasks();
          this.resetForm();
        },
        error: (error) => console.error('Error al crear:', error)
      });
    }
  }

  editTask(task: Task): void {
    this.currentTask = { ...task };
    this.editingTask = true;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  deleteTask(id: number): void {
    if (confirm('¿Estás seguro de eliminar esta tarea?')) {
      this.taskService.deleteTask(id).subscribe({
        next: () => this.loadTasks(),
        error: (error) => console.error('Error al eliminar:', error)
      });
    }
  }

  toggleComplete(task: Task): void {
    const updatedTask = { ...task, completed: !task.completed };
    this.taskService.updateTask(task.id!, updatedTask).subscribe({
      next: () => this.loadTasks(),
      error: (error) => console.error('Error al actualizar:', error)
    });
  }

  cancelEdit(): void {
    this.resetForm();
  }

  resetForm(): void {
    this.currentTask = { title: '', description: '', completed: false };
    this.editingTask = false;
  }
}
