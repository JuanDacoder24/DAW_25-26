package com.example.examen.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.examen.entity.Jugador;

public interface JugadorRepository extends JpaRepository<Jugador, String>{

    List<Jugador> findByEquipoId(int equipoId);


}
