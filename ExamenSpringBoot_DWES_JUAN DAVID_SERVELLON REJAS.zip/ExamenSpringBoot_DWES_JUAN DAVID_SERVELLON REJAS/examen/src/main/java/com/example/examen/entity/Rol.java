package com.example.examen.entity;

public enum Rol {

    PRINCIPAL, ASISTENTE

}
