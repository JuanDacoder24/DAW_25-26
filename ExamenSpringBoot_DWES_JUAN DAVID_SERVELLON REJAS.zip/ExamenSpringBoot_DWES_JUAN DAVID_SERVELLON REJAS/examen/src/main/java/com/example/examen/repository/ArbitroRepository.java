package com.example.examen.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.examen.entity.Arbitro;

public interface ArbitroRepository extends JpaRepository<Arbitro, String>{

}
