package com.example.examen.repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Partido extends JpaRepository<Partido, String>{

}
