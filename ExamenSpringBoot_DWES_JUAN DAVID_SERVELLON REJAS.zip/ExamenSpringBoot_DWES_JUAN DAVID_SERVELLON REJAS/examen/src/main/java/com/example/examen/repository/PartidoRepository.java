package com.example.examen.repository;

public class PartidoRepository {

}
