package com.example.examen.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.examen.entity.Equipo;

public interface EquipoRepository extends JpaRepository<Equipo, Integer>{

}
