package com.example.examen.entity;

public enum Posiciones {

    PORTERO, DEFENSA, MEDIO, DELANTERO

}
